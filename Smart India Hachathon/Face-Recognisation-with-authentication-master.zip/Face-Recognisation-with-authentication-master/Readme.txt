chmod +x script.sh
./script.sh

