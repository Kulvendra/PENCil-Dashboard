#!/bin/bash
source ../Project/env/bin/activate
python encode.py
python3 Face_Recognizer.py


